package com.thinglinks.protocol.deal;

import com.alibaba.fastjson2.JSONObject;
import com.thinglinks.protocol.message.DecodeMessage;
import com.thinglinks.protocol.message.EncodeMessage;
import com.thinglinks.protocol.parent.TcpServerProtocol;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @Description: TCP消息处理
 * @Author: thinglinks
 * @CreateTime: 2025-09-17
 */
public class TcpServerDeal implements TcpServerProtocol {

    @Override
    public DecodeMessage decode(String rawData) throws Exception {
        DecodeMessage decodeMessage = new DecodeMessage();
        JSONObject data = JSONObject.parseObject(rawData);
        decodeMessage.setDeviceSn(data.getString("deviceSn"));
        decodeMessage.setReportTime(new Date());
        Map<String,Object> map = new HashMap<>();
        data.keySet().forEach(key->{
            map.put(key,data.get(key));
        });
        decodeMessage.setProperties(map);
        return decodeMessage;
    }

    @Override
    public EncodeMessage encode(String functionCode, String deviceSn, Map<String,Object> properties, String params,String customConfig) throws Exception {
        return new EncodeMessage();
    }
}
