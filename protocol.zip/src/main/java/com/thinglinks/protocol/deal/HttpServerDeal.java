package com.thinglinks.protocol.deal;

import com.alibaba.fastjson2.JSONObject;
import com.thinglinks.protocol.message.DecodeMessage;
import com.thinglinks.protocol.message.EncodeMessage;
import com.thinglinks.protocol.parent.HttpServerProtocol;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @Description: HTTP消息处理
 * @Author: thinglinks
 * @CreateTime: 2025-09-17
 */
public class HttpServerDeal implements HttpServerProtocol {

    @Override
    public DecodeMessage decode(String requestMethod, String requestPath, String contentType, Map<String, String> headers, Map<String, String> queryParams, String requestBody, Map<String, String> formData) throws Exception {
        DecodeMessage decodeMessage = new DecodeMessage();
        JSONObject data = JSONObject.parseObject(requestBody);
        decodeMessage.setDeviceSn(data.getString("deviceSn"));
        decodeMessage.setReportTime(new Date());
        Map<String,Object> map = new HashMap<>();
        data.keySet().forEach(key->{
            map.put(key,data.get(key));
        });
        decodeMessage.setProperties(map);
        decodeMessage.setHttNeedReply(false);
        decodeMessage.setHttpReply(requestBody);
        return decodeMessage;
    }

    @Override
    public EncodeMessage encode(String functionCode, String deviceSn, Map<String,Object> properties, String params,String clientIp,Integer clientPort,String customConfig) throws Exception {
        return new EncodeMessage();
    }
}
