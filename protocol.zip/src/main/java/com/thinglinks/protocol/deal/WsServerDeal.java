package com.thinglinks.protocol.deal;

import com.alibaba.fastjson2.JSONObject;
import com.thinglinks.protocol.message.DecodeMessage;
import com.thinglinks.protocol.message.EncodeMessage;
import com.thinglinks.protocol.parent.UdpServerProtocol;
import com.thinglinks.protocol.parent.WsServerProtocol;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @Description: UDP消息处理
 * @Author: chen tao
 * @CreateTime: 2025-09-17
 */
public class WsServerDeal implements WsServerProtocol {

    @Override
    public DecodeMessage decode(Integer wsPort,String wsPath,String message) throws Exception {
        DecodeMessage decodeMessage = new DecodeMessage();
        JSONObject data = JSONObject.parseObject(message);
        decodeMessage.setDeviceSn(data.getString("deviceSn"));
        decodeMessage.setReportTime(new Date());
        Map<String,Object> map = new HashMap<>();
        map.put("inTemperature",data.getDoubleValue("inTemperature"));
        map.put("outTemperature",data.getDoubleValue("outTemperature"));
        map.put("humidity",data.getDoubleValue("humidity"));
        map.put("voice",data.getDoubleValue("voice"));
        map.put("windSpeed",data.getDoubleValue("windSpeed"));
        map.put("deviceSn",data.getString("deviceSn"));
        decodeMessage.setProperties(map);
        return decodeMessage;
    }

    @Override
    public EncodeMessage encode(String functionCode, String deviceSn, Map<String, Object> properties, String params, String customConfig) throws Exception {
        return EncodeMessage.builder()
                .isSend(true)
                .deviceSn(deviceSn)
                .content("下发指令给设备测试".getBytes(StandardCharsets.UTF_8))
                .build();
    }
}
