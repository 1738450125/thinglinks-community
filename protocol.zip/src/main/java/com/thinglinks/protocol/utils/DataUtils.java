package com.thinglinks.protocol.utils;

/**
 * @Description:
 * @Author: chen tao
 * @CreateTime: 2025-09-17
 */
public class DataUtils {
    public static String deal(){
        return "jklfdsjaflkj";
    }
}
