package com.thinglinks.protocol.parent;

import com.alibaba.fastjson2.JSONArray;
import com.thinglinks.protocol.message.DecodeMessage;
import com.thinglinks.protocol.message.EncodeMessage;

import java.util.Map;

/**
 * COAP服务端协议包必须实现的统一接口。
 */
public interface ModbusTcpProtocol {

    /**
     * 解析设备寄存器的数据
     * @param deviceSn 设备SN
     * @param slaveId modbus从站ID
     * @param code 解析动作code
     * @param registerRange 配置的寄存器范围
     * @param jsonArray 读取到的寄存器数据
     * @return 解析后的标准化数据，必须是DecodeMessage类
     * @throws Exception 解析异常
     */
    DecodeMessage decode(String deviceSn, Integer slaveId, String code, String registerRange, JSONArray jsonArray) throws Exception;

    /**
     * 功能下行指令（平台向设备发送数据）
     *
     * @param functionCode 功能编码
     * @param deviceSn     设备标识
     * @param properties   设备最新全属性状态
     * @param params       用户自定义参数
     * @param customConfig 设备自定义配置
     * @return 需要下发的配置信息
     * @throws Exception 编码异常
     */
    EncodeMessage encode(String functionCode, String deviceSn, Map<String, Object> properties, String params,String customConfig) throws Exception;
}
